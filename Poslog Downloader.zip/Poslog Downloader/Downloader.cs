﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using WinSCP;
using System.Diagnostics;
using System.Threading;

namespace Poslog_Downloader
{
    public class Downloader
    {
        public static string logdir = Path.Combine(Directory.GetCurrentDirectory(), "Log");
        public static string logfile = Path.Combine(logdir, "Log.txt");

        public static string inputFile = Path.Combine(Directory.GetCurrentDirectory(), "poslog.txt");
        public static string outPutFolder = Path.Combine(Directory.GetCurrentDirectory(), "Copied");
        public static string baseDir = "c:/Centric/Backup/OBP";
        public static string username = "root";

        public static void Main()
        {
            // Check if required files and directories exist.

            Log($"Log from last run on {DateTime.Now.ToLongDateString()} - {DateTime.Now.ToLongTimeString()}. \n");

            if (!Directory.Exists(outPutFolder))
            {
                Console.WriteLine("Output folder not found, creating folder..");
                Directory.CreateDirectory(outPutFolder);
            }
            else
            {
                Console.WriteLine("Remove previous output files? y/n \n");
                string output = Console.ReadLine();

                switch (output)
                {
                    case "y":
                        Directory.Delete(outPutFolder, true);
                        Directory.CreateDirectory(outPutFolder);
                        break;
                    case "n":
                        break;
                    default:
                        Console.WriteLine("Invalid input given.");
                        break;
                }
            }

            Stopwatch timer = new Stopwatch();
            timer.Start();

            // Proceed to download files based on input provided in poslog.txt file.

            foreach (var item in Retrieve_input(inputFile))
            {
                DateTime date = Convert.ToDateTime(item.Date);
                DateTime hour = Convert.ToDateTime(item.Hour);
                DateTime hour2 = hour.AddHours(1);
                string Month = date.Month.ToString();

                // Month has to be parsed as 2 digits if < 10
                if (Month.Length < 2)
                {
                    Month = "0" + Month;
                }

                string filePath = Path.Combine(baseDir, date.Year.ToString(), Month, date.Day.ToString(), hour.Hour.ToString(), item.Id);
                string filePathRetry = Path.Combine(baseDir, date.Year.ToString(), Month, date.Day.ToString(), hour2.Hour.ToString(), item.Id);
                string fileName = Path.Combine(outPutFolder, item.Id);

                downloadFile(filePath, fileName, filePathRetry, item);
            }

            timer.Stop();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"Downloaded {Directory.GetFiles(outPutFolder).Length} files in {timer.Elapsed}.");
            Console.WriteLine("\nCheck /Copied folder in current directory for donwloaded files.");
            Console.WriteLine("Check /Logs for any errors.");
            Console.WriteLine("\nPress enter to exit...");
            Console.ReadLine();
        }

        public static void downloadFile(string input, string output, string retryPath, Pair pair)
        {

            int retry = 0;

            SessionOptions options = new SessionOptions
            {
                Protocol = Protocol.Scp,
                HostName = pair.Hostname,
                UserName = username,
                Password = Get_pwd(pair.Hostname),
                GiveUpSecurityAndAcceptAnySshHostKey = true
            };

            using (Session session = new Session())
            {
                try
                {
                    session.Open(options);
                    session.GetFiles(input, output, false).Check();
                }
                catch (FileNotFoundException e)
                {
                    if (retry < 1)
                    {
                        Console.WriteLine("File not found, retrying in next folder...");
                        Log("File not found, retrying in next folder...");

                        try
                        {
                            Console.WriteLine($"Downloading {pair.Id} from {pair.Hostname}...");

                            session.GetFiles(retryPath, output, false).Check();
                            retry += 1;

                            Console.WriteLine($"Downloaded {pair.Id} from {pair.Hostname}.");
                        }
                        catch (Exception)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($"Retry failed for {input}.");
                            Log($"Retry failed for {input}.");
                            retry += 1;
                        }
                    }
                    else
                    {
                        Log($"Downloading {input} from {pair.Hostname} failed due to FileNotFoundException.");
                    }
                }
                catch (Exception ex)
                {
                    Log($"Downloading {input} from {pair.Hostname} failed due to {ex.Message}.");
                }
                finally
                {
                    session.Dispose();
                }
            }
        }

        public static void Log(string Message)
        {
            try
            {
                using (StreamWriter writer = File.AppendText(logfile))
                {
                    writer.WriteLine("\n" + Message);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Writing to log failed due to: {ex.Message}.");
            }
        }

        static string Get_pwd(string input)
        {

            // Method returns password for root user based on hostname.
            // To avoid COOP hostname issues, usage of storenumber in query is an option.

            string result = Regex.Replace(input, @"\D", "");
            return string.Concat("admin", result.Substring(0, 4));
        }

        static List<Pair> Retrieve_input(string file)
        {

            // Method returns a list of Pairs (Filename, Hostname, Date, Hour) to retrieve.

            if (File.Exists(file))
            {
                List<string> readText = File.ReadAllLines(file).ToList();
                List<Pair> files = new List<Pair>();

                foreach (var line in readText)
                {
                    string[] entries = line.Split(',');

                    Pair Items = new Pair
                    {
                        Id = entries[0],
                        Hostname = entries[1],
                        Date = entries[2],
                        Hour = entries[3]
                    };

                    files.Add(Items);
                }
                return files;
            }
            else
            {
                Console.WriteLine("No poslog.txt input file was provided, created dummy file.");

                File.Create(file);

                return new List<Pair>();
            }
        }
    }
}
